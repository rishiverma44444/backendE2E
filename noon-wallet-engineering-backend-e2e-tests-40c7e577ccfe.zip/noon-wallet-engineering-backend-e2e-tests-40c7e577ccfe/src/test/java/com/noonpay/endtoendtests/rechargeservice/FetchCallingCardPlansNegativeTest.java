package com.noonpay.endtoendtests.rechargeservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

// PENDING --> Need to replace path params value to dynamic & in verifyValueOfCountryIdKey method
@TestDataSetup(endpoint = "/recharge/v1/fetch/cards/plans?serviceId=999")
public class FetchCallingCardPlansNegativeTest extends BaseTest {

    static Logger logger = Logger.getLogger(FetchCallingCardPlansNegativeTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchCallingCardPlansNegative")
    private Response apiCall(TestData data) {
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        RechargeResponse.rechargeData.put("Response_fetchCallingCardPlansNegative", apiResponse.asString());
        logger.info("Api response =>" + RechargeResponse.rechargeData.get("Response_fetchCallingCardPlansNegative"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansNegative")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansNegative")
    public void verifyValueOfStatusKey(Response response) {
        Utility.checkValueFromResponse(response, "status", "BAD_REQUEST");
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansNegative")
    public void verifyValueOfMessageKey(Response response) {
        Utility.checkValueFromResponse(response, "message", "Request parameter : serviceId is not valid");
    }

}

