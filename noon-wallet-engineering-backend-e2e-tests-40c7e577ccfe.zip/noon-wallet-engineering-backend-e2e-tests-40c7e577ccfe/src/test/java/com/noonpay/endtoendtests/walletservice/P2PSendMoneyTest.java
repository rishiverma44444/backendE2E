package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.util.Map;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/p2p/v1/send")
public class P2PSendMoneyTest extends BaseTest {

	@Autowired
	private APIUrlProvider apiUrlProvider;

	@Autowired
	private RestAssuredClient restAssuredClient;

	@Api(name = "p2pSendMoney")
	private Response apiCall(TestData data) {
		data = P2PSendMoney.populateData(data);
		String formattedString = data.getSampleRequest().replace("\\", "");
		Map map = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders(),
				formattedString, data.getProperties());
		Response response = (Response) map.get("response");
		WalletResponse.walletData.put("Response_P2PSend", response.getBody().asString());
		return response;
	}

	@Test(groups = { "actualCall" }, dataProvider = "dataProvider", dependsOnGroups = { "preBalanceCall" })
	@ApiTest(api = "p2pSendMoney")
	public void verifyStatusCode(Response response) {
		assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
	}

	@Test(groups = { "actualCall" }, dataProvider = "dataProvider", dependsOnGroups = { "preBalanceCall" })
	@ApiTest(api = "p2pSendMoney")
	public void verifyValueOfStatusKey(Response response) {
		response.then().assertThat().body("status", equalTo("OK"));
	}

	@Api(name = "p2pBlank")
	public void apiCall3() {
	}

	@Test(dependsOnMethods = { "verifyValueOfStatusKey" })
	@ApiTest(api = "p2pBlank")
	public void verifySenderWalletMoneyIsDeductedAfterP2P() {
		String senderBalanceBeforeP2P = WalletResponse.walletData.get("CustomerMainBalanceBefore").toString();
		double senBalanceBeforeP2P = Utility.convertStringIntoDouble(senderBalanceBeforeP2P);
		String balanceAfterP2P = WalletResponse.walletData.get("CustomerMainBalanceAfter").toString();
		double customerBalanceAfterP2P = Utility.convertStringIntoDouble(balanceAfterP2P);
		assertEquals(customerBalanceAfterP2P, senBalanceBeforeP2P - 10.00);
	}

	@Api(name = "p2pSendMoneyToKyc1")
	private Response apiCall1(TestData data) {
		data = P2PSendMoney.populateDataForSendMoneyToKyc1(data);
		String formattedString = data.getSampleRequest().replace("\\", "");
		Map map = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders(),
				formattedString, data.getProperties());
		Response response = (Response) map.get("response");
		WalletResponse.walletData.put("Response_P2PSendToKyc1", response.getBody().asString());
		return response;
	}

	@Test(dataProvider = "dataProvider")
	@ApiTest(api = "p2pSendMoneyToKyc1")
	public void verifyApiCodeForP2PToKyc1(Response response) {
		assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
	}

	@Test(dataProvider = "dataProvider")
	@ApiTest(api = "p2pSendMoneyToKyc1")
	public void verifyApiStatusForP2PToKyc1(Response response) {
		response.then().assertThat().body("status", equalTo("OK"));
	}

	@Api(name = "p2pSendMoneyToOtherCountry")
	private Response apiCall2(TestData data) {
		data = P2PSendMoney.populateDataForSendMoneyToOtherCountry(data);
		String formattedString = data.getSampleRequest().replace("\\", "");
		Map map = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders(),
				formattedString, data.getProperties());
		Response response = (Response) map.get("response");
		WalletResponse.walletData.put("Response_P2PSendToOtherCountry", response.getBody().asString());
		return response;
	}

	@Test(dataProvider = "dataProvider")
	@ApiTest(api = "p2pSendMoneyToOtherCountry")
	public void verifyStatusForP2PToOtherCountry(Response response) {
		response.then().assertThat().body("status", equalTo("BAD_REQUEST"));
	}

	@Test(dependsOnMethods = { "verifySenderWalletMoneyIsDeductedAfterP2P" })
	@ApiTest(api = "p2pBlank")
	public void verifyReceiverWalletMoneyIsCreditedAfterP2P() {
		String receiverBalanceBefore = WalletResponse.walletData.get("ReceiverMainBalanceBefore").toString();
		double receiverMainBalanceBefore = Utility.convertStringIntoDouble(receiverBalanceBefore);

		String receiverBalanceAfter = WalletResponse.walletData.get("ReceiverMainBalanceAfter").toString();
		double receiverMainBalanceAfter = Utility.convertStringIntoDouble(receiverBalanceAfter);

		assertEquals(receiverMainBalanceAfter, receiverMainBalanceBefore + 10.00);
	}
}
