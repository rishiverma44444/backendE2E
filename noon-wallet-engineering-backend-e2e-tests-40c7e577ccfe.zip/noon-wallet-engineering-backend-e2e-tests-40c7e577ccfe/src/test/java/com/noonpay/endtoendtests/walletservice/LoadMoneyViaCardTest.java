package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/wallet/customer/v1/credit?f=LOAD_MONEY_PG")
public class LoadMoneyViaCardTest extends BaseTest {

	static Logger logger = Logger.getLogger(LoadMoneyViaCardTest.class);

	@Autowired
	private APIUrlProvider apiUrlProvider;

	@Autowired
	private RestAssuredClient restAssuredClient;

	@Api(name = "walletLoadBalance")
	private Response apiCall(TestData data) {
		ApiRequest request = getRequestId(data);
		String reqBody = getRequestBody(data.getService());
		request.getDynamicPayload().setProperty("amount", WalletServiceConstants.amountToAdd);
		request.getDynamicPayload().setProperty("currency", WalletServiceConstants.uaeCurrency);
		request.getDynamicPayload().setProperty("txn_ref_id", Utility.generate16CharRndStr());
		BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
				request.getHeaders(), reqBody, request.getDynamicPayload());
		Response apiResponse = response.getResponse();
		WalletResponse.setWalletData("Response_LoadMoneyViaCardTest", apiResponse);
		return apiResponse;
	}

	@Test(dataProvider = "dataProvider", groups = { "actualCall" }, dependsOnGroups = { "preBalanceCall" })
	@ApiTest(api = "walletLoadBalance")
	public void verifyStatusCode(Response response) {
		assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
	}

	@Test(dataProvider = "dataProvider", groups = { "actualCall" }, dependsOnGroups = { "preBalanceCall" })
	@ApiTest(api = "walletLoadBalance")
	public void verifyValueOfStatusKey(Response response) {
		response.then().assertThat().body("status", equalTo("OK"));
	}

	@SuppressWarnings("unchecked")
	@Test(dependsOnGroups = { "afterCall" })
	private void verifyIfMoneyIsLoadedToCustomerWallet() {
		String balanceResponseBefore = WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
		double mainBalanceBefore = Utility.convertStringIntoDouble(data.get("main_balance").toString());
		logger.info("mainBalanceBefore=>" + mainBalanceBefore);

		String balanceResponseAfter = WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
		Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter)
				.get("data");
		double mainBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("main_balance").toString());

		double amountCredited = Utility.convertStringIntoDouble(WalletServiceConstants.amountToAdd);
		BigDecimal expAmountAfterAddition = BigDecimal.valueOf(mainBalanceBefore)
				.add(BigDecimal.valueOf(amountCredited));
		logger.info("expAmountAfterAddition=>" + expAmountAfterAddition);
		double expAmount = expAmountAfterAddition.doubleValue();
		assertEquals(mainBalanceAfter, expAmount);

	}
}
