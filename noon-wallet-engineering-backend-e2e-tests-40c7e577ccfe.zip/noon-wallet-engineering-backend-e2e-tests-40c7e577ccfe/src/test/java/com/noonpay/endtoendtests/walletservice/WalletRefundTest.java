package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/wallet/customer/v2/refund?f=M_ON")
public class WalletRefundTest extends BaseTest{
	
	static Logger logger = Logger.getLogger(WalletRefundTest.class);

	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "walletRefund")
    private Response apiCallForRefund(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	request.getDynamicPayload().setProperty("refund_amount", WalletServiceConstants.amount);
    	request.getDynamicPayload().setProperty("currency", WalletServiceConstants.uaeCurrency);
    	logger.info("DEBIT TXN ID=>"+WalletDebitTest.getDebitTxnId());
    	request.getDynamicPayload().setProperty("txn_id", WalletDebitTest.getDebitTxnId());
    	BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                request.getHeaders(), reqBody, request.getDynamicPayload());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_WalletRefundTest", apiResponse);
		return apiResponse;
    }
    
    @Test(groups="actualCall", dataProvider = "dataProvider")
    @ApiTest(api = "walletRefund")
    public void verifyApiCodeForRefund(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(groups="actualCall", dataProvider = "dataProvider")
	@ApiTest(api = "walletRefund")
	public void verifyApiStatusKeyForRefund(Response response) {
		response.then().assertThat().body("status", equalTo("OK"));
	}
    
    @SuppressWarnings("unchecked")
	@Test(dependsOnGroups= {"afterCall"})
    public void verifyBalanceAfterRefund() {
    	String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	double mainBalanceBefore = Utility.convertStringIntoDouble(data.get("main_balance").toString());
    	logger.info("mainBalanceBefore=>"+mainBalanceBefore);
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double mainBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("main_balance").toString());
    	logger.info("mainBalanceAfter=>"+mainBalanceAfter);
    	
    	String balanceResponseBefore1=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data1 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore1).get("data");
    	double cashbackBalanceBefore = Utility.convertStringIntoDouble(data1.get("cashback_balance").toString());
    	logger.info("cashbackBalanceBefore=>"+cashbackBalanceBefore);
    	
    	String balanceResponseAfter1=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter1 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter1).get("data");
    	double cashbackBalanceAfter = Utility.convertStringIntoDouble(dataAfter1.get("cashback_balance").toString());
    	logger.info("cashbackBalanceAfter=>"+cashbackBalanceAfter);
    	
    	double mainBlncDiff=WalletDebitTest.differenceInMainBlnc;
    	logger.info("mainBlncDiff=>"+mainBlncDiff);
    	double cbBlncDiff=WalletDebitTest.differenceInCBBlnc;
    	logger.info("cbBlncDiff=>"+cbBlncDiff);
    	
    	BigDecimal expAmountAfterAddition=BigDecimal.valueOf(mainBalanceBefore).add(BigDecimal.valueOf(mainBlncDiff));
    	double expMainBlnc=expAmountAfterAddition.doubleValue();
    	logger.info("expMainBlnc=>"+expMainBlnc);
    	assertEquals(mainBalanceAfter, expMainBlnc);
    	
    	BigDecimal expCBAmtAfterAddition=BigDecimal.valueOf(cashbackBalanceBefore).add(BigDecimal.valueOf(cbBlncDiff));
    	double expCBBlnc=expCBAmtAfterAddition.doubleValue();
    	logger.info("expCBBlnc=>"+expCBBlnc);
    	assertEquals(cashbackBalanceAfter, expCBBlnc);
    			
    }
}
