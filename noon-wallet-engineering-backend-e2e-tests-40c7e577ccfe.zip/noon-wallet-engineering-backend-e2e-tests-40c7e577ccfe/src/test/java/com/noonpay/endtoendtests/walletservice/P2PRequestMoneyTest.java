package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.util.Map;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/p2p/v1/request")
public class P2PRequestMoneyTest extends BaseTest{

	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

	@Api(name = "p2pRequestMoney")
	private Response apiCall(TestData data) {
		data = P2PRequestMoney.populateDataForP2P(data);
		String formattedString = data.getSampleRequest().replace("\\", "");
		Map map = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders(),
				formattedString, data.getProperties());
		Response response = (Response) map.get("response");
		WalletResponse.walletData.put("Response_P2PRequest", response.asString());
		return response;
	}
    
	@Test(dataProvider = "dataProvider")
	@ApiTest(api = "p2pRequestMoney")
	public void verifyStatusCode(Response response) {
		assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
	}

	@Test(dataProvider = "dataProvider")
	@ApiTest(api = "p2pRequestMoney")
	public void verifyValueOfStatusKey(Response response) {
		response.then().assertThat().body("status", equalTo("OK"));
	}

	@Api(name = "p2pRequestMoneyLimitCheck")
	private Response apiCall1(TestData data) {
		Response response = null;
		int requestMoneyLimit=P2PRequestMoney.requestMoneyLimit;
		for (int i = 0; i <= requestMoneyLimit; i++) {
			data = P2PRequestMoney.populateDataForP2PLimitCheck(data);
			String formattedString = data.getSampleRequest().replace("\\", "");
			Map map = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders(),
					formattedString, data.getProperties());
			response = (Response) map.get("response");
			WalletResponse.walletData.put("Response_P2PRequest", response.asString());
		}
		return response;
	}

	@Test(dataProvider = "dataProvider")
	@ApiTest(api = "p2pRequestMoneyLimitCheck")
	public void verifyRequestMoneyLimit(Response response) {
		response.then().assertThat().body("status", equalTo("BAD_REQUEST"));
	}
}
