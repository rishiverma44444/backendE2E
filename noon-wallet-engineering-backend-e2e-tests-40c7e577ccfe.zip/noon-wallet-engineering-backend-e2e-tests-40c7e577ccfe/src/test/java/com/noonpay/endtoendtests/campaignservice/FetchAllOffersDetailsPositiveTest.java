package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.*;
import static org.testng.Assert.assertEquals;

// PENDING --> Need to replace path params value to dynamic (HOME, OFFER)
@TestDataSetup(endpoint = "/campaign/v1/offers?s=HOME")
public class FetchAllOffersDetailsPositiveTest extends BaseTest {
    static Logger logger = Logger.getLogger(FetchAllOffersDetailsPositiveTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchAllOffersDetailsPositive")
    private Response apiCall_fetchAllOffersDetailsPositive(TestData data) {
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_fetchAllOffersDetailsPositive", apiResponse.asString());
        logger.info("Api response =>" + CampaignResponse.campaignData.get("Response_fetchAllOffersDetailsPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllOffersDetailsPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllOffersDetailsPositive")
    public void verifyValueOfStatusKey(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }

}
