package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.custom.report.CustomLogger;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.testng.Assert.assertEquals;


@TestDataSetup(endpoint = "/campaign/v1/add")
public class AddCampaignTest extends BaseTest {

    static Logger logger = Logger.getLogger(AddCampaignTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "addCampaignPositive")
    private Response apiCall_addCampaignPositive(TestData data) {
        data = AddCampaign.populateDataForPositiveFlow(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_addCampaignPositive", apiResponse.asString());
        logger.info("Add campaign positive api response =>" +CampaignResponse.campaignData.get("Response_addCampaignPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignPositive")
    public void verifyValueOfStatusKey(Response response) {
        Utility.checkValueFromResponse(response, "status",
                "OK");
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignPositive")
    public void verifyValueOfDataKey(Response response) {
        Utility.checkValueFromResponse(response, "data",
                true);
    }

    @Api(name = "addCampaignNegative_StartTime")
    private Response apiCall_addCampaignNegativeStartTime(TestData data) {
        data = AddCampaign.populateDataForPastStartTime(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_addCampaignNegative_StartTime", apiResponse.asString());
        logger.info("Add campaign negative start time api response =>" +CampaignResponse.campaignData.get("Response_addCampaignNegative_StartTime"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignNegative_StartTime")
    public void verifyStatusCode_NegativeStartTime(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignNegative_StartTime")
    public void verifyValueOfStatusKey_NegativeStartTime(Response response) {
        Utility.checkValueFromResponse(response, "status", "BAD_REQUEST");
    }


    @Api(name = "addCampaignNegative_EndTime")
    private Response apiCall_addCampaignNegativeEndTime(TestData data) {
        data = AddCampaign.populateDataForPastEndTime(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_addCampaignNegative_EndTime", apiResponse.asString());
        logger.info("Add campaign negative end time api response =>" +CampaignResponse.campaignData.get("Response_addCampaignNegative_EndTime"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignNegative_EndTime")
    public void verifyStatusCode_NegativeEndTime(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignNegative_EndTime")
    public void verifyValueOfStatusKey_NegativeEndTime(Response response) {
        Utility.checkValueFromResponse(response, "status", "BAD_REQUEST");
    }

    @Api(name = "addCampaignNegative_InvalidOfferId")
    private Response apiCall_addCampaignNegativeInvalidOfferId(TestData data) {
        data = AddCampaign.populateDataForInvalidOffer(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_addCampaignNegative_InvalidOfferId", apiResponse.asString());
        logger.info("Add campaign invalid offerId api response =>" +CampaignResponse.campaignData.get("Response_addCampaignNegative_InvalidOfferId"));

        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignNegative_InvalidOfferId")
    public void verifyStatusCode_NegativeOfferId(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_INTERNAL_SERVER_ERROR);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "addCampaignNegative_InvalidOfferId")
    public void verifyValueOfStatusKey_NegativeOfferId(Response response) {
        Utility.checkValueFromResponse(response, "status", "INTERNAL_SERVER_ERROR");
    }


}
