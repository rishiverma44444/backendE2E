package com.noonpay.endtoendtests.pos;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Constants;
import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.endtoendtests.walletservice.WalletResponse;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/pos/customer/v1/debit")
public class PosDebitTest extends BaseTest{

	static Logger logger = Logger.getLogger(PosDebitTest.class);
	
	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;
    
    @Api(name = "posDebitWalletBlnc")
    private Response apiCall(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	request.getDynamicPayload().setProperty("country", "UAE");
    	request.getDynamicPayload().setProperty("currency", Constants.uaeCurrency);
    	request.getDynamicPayload().setProperty("load_amount", "0.00");
    	request.getDynamicPayload().setProperty("pay_amount", PosConstants.amount);
    	request.getDynamicPayload().setProperty("secondary_user_id", PosConstants.merchantId);
    	request.getDynamicPayload().setProperty("txn_ref_id", Utility.generate16CharRndStr());
    	BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                request.getHeaders(), reqBody, request.getDynamicPayload());
    	Response apiResponse =response.getResponse();
    	PosResponse.setPosData("Response_PosDebitWalletBalance", apiResponse);
		return apiResponse;
    }
    
    @Test(groups= {"actualCall","actualCall1"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall"})
    @ApiTest(api = "posDebitWalletBlnc")
    public void verifyApiCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(groups= {"actualCall","actualCall1"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall"})
    @ApiTest(api = "posDebitWalletBlnc")
    public void verifyApiStatus(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }
    
    @SuppressWarnings("unchecked")
	@Test(dependsOnGroups= {"afterCall"})
    public void validateAmountDebited() {
    	String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	double totalBalanceBefore = Utility.convertStringIntoDouble(data.get("total_balance").toString());
    	logger.info("totalBalanceBefore=>"+totalBalanceBefore);
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double totalBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("total_balance").toString());
    	double amountUsed=Utility.convertStringIntoDouble(PosConstants.amount);
    	BigDecimal expAmount=BigDecimal.valueOf(totalBalanceBefore).subtract(BigDecimal.valueOf(amountUsed));
    	double expAmountUsed=expAmount.doubleValue();
    	logger.info("expAmountUsed=>"+expAmountUsed);
    	
    	assertEquals(totalBalanceAfter, expAmountUsed);
    }
    
    
}
