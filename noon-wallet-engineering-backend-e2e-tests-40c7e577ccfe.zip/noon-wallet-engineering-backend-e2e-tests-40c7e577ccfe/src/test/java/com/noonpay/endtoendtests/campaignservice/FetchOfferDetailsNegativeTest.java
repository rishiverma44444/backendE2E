package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

// PENDING --> Need to replace path params value to dynamic
@TestDataSetup(endpoint = "/campaign/v1/offer/e2eOffer_001")
public class FetchOfferDetailsNegativeTest extends BaseTest {
    static Logger logger = Logger.getLogger(FetchOfferDetailsNegativeTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchOfferDetailsNegative")
    private Response apiCall_fetchOfferDetailsNegative(TestData data) {
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_fetchOfferDetailsNegative", apiResponse.asString());
        logger.info("Api response =>" + CampaignResponse.campaignData.get("Response_fetchOfferDetailsNegative"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchOfferDetailsNegative")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_INTERNAL_SERVER_ERROR);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchOfferDetailsNegative")
    public void verifyValueOfStatusKey(Response response) {
        response.then().assertThat().body("status", equalTo("INTERNAL_SERVER_ERROR"));
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchOfferDetailsNegative")
    public void verifyValueOfMessageKey(Response response) {
        response.then().assertThat().body("message", equalTo("No Offers Details Available"));
    }

}
