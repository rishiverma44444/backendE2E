package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;


@TestDataSetup(endpoint = "/wallet/customer/v2/balance/all")
public class CheckCustomerBalanceTest extends BaseTest{

	static Logger logger = Logger.getLogger(CheckCustomerBalanceTest.class);
	
	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;
    
    @SuppressWarnings("unchecked")
	@Api(name = "customerWalletBalanceBefore")
    private Response checkBalanceForCustomerBefore(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	Map queryParam=new HashMap();
    	queryParam.put("c", WalletServiceConstants.uaeCurrency);
    	request.setQueryParams(queryParam);
    	BaseResponse response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), request.getHeaders(), request.getQueryParams());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_CheckCustomerBalanceBefore", apiResponse);
    	String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
    	Map<String, Object> data1 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	
    	double mainBalanceBefore = Utility.convertStringIntoDouble(data1.get("main_balance").toString());
    	
    	double cashbackBalanceBefore = Utility.convertStringIntoDouble(data1.get("cashback_balance").toString());
    	logger.info("MainBalanceBefore=>"+mainBalanceBefore);
    	logger.info("CashbackBalanceBefore=>"+cashbackBalanceBefore);
        return apiResponse;
    }
    
    @Test(dataProvider = "dataProvider", groups = {"preBalanceCall"})
    @ApiTest(api = "customerWalletBalanceBefore")
    public void verifyGetBalanceApiCodeBefore(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(dataProvider = "dataProvider", groups = {"preBalanceCall"})
    @ApiTest(api = "customerWalletBalanceBefore")
    public void verifyGetBalanceApiStatusBefore(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }
    
    @SuppressWarnings("unchecked")
	@Api(name = "customerWalletBalanceAfter")
    private Response checkBalanceForCustomerAfter(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	Map queryParam=new HashMap();
    	queryParam.put("c", WalletServiceConstants.uaeCurrency);
    	request.setQueryParams(queryParam);
    	BaseResponse response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), request.getHeaders(), request.getQueryParams());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_CheckCustomerBalanceAfter", apiResponse);
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double mainBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("main_balance").toString());
    	double cashbackBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("cashback_balance").toString());
    	logger.info("MainBalanceAfter=>"+mainBalanceAfter);
    	logger.info("CashbackBalanceAfter=>"+cashbackBalanceAfter);
        return apiResponse;
    }
    
    @Test(dataProvider = "dataProvider", groups="afterCall", dependsOnGroups= {"actualCall"})
    @ApiTest(api = "customerWalletBalanceAfter")
    public void verifyGetBalanceApiCodeAfter(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(dataProvider = "dataProvider", groups="afterCall", dependsOnGroups= {"actualCall"})
    @ApiTest(api = "customerWalletBalanceAfter")
    public void verifyGetBalanceApiStatusAfter(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }

}
