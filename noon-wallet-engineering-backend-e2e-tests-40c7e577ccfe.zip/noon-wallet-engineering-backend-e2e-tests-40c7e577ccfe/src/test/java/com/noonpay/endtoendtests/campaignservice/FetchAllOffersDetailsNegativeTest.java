package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

// PENDING --> Need to replace path params value to dynamic
@TestDataSetup(endpoint = "/campaign/v1/offers?s=TEST")
public class FetchAllOffersDetailsNegativeTest extends BaseTest {
    static Logger logger = Logger.getLogger(FetchAllOffersDetailsNegativeTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchAllOffersDetailsNegative")
    private Response apiCall_fetchAllOffersDetailsNegative(TestData data) {
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_fetchAllOffersDetailsNegative", apiResponse.asString());
        logger.info("Api response =>" + CampaignResponse.campaignData.get("Response_fetchAllOffersDetailsNegative"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllOffersDetailsNegative")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllOffersDetailsNegative")
    public void verifyValueOfStatusKey(Response response) {
        response.then().assertThat().body("status", equalTo("BAD_REQUEST"));
    }

}
