package com.noonpay.endtoendtests.rechargeservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

// PENDING --> Need to replace path params value to dynamic & in verifyValueOfCountryIdKey method
@TestDataSetup(endpoint = "/recharge/v1/fetch/cards/plans?serviceId=1")
public class FetchCallingCardPlansPositiveTest extends BaseTest {

    static Logger logger = Logger.getLogger(FetchCallingCardPlansPositiveTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchCallingCardPlansPositive")
    private Response apiCall(TestData data) {
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        RechargeResponse.rechargeData.put("Response_fetchCallingCardPlansPositive", apiResponse.asString());
        logger.info("Api response =>" + RechargeResponse.rechargeData.get("Response_fetchCallingCardPlansPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansPositive")
    public void verifyValueOfStatusKey(Response response) {
        Utility.checkValueFromResponse(response, "status", "OK");
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansPositive")
    public void verifyCallingCardPlansNotNull(Response response) {
        String apiResponse = RechargeResponse.rechargeData.get("Response_fetchCallingCardPlansPositive");
        Utility.checkSizeOfArrayNotNull(apiResponse, "$..plans[0:]");
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchCallingCardPlansPositive")
    public void verifyValueOfProductNameKey(Response response) {
        String apiResponse = RechargeResponse.rechargeData.get("Response_fetchCallingCardPlansPositive");
        String productName = Utility.getValueFromJsonPath(apiResponse, "$.data.plans[0].product_name");
        assertEquals(productName, "DU-MT");
    }

}



