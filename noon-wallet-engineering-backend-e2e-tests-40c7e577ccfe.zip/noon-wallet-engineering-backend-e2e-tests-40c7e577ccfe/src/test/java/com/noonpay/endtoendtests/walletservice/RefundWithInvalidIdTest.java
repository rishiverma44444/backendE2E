package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/wallet/customer/v2/refund?f=M_ON")
public class RefundWithInvalidIdTest extends BaseTest{

	static Logger logger = Logger.getLogger(RefundWithInvalidIdTest.class);

	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;
    
    @Api(name = "refundWithWrongTxnId")
    private Response apiCallForRefund(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	request.getDynamicPayload().setProperty("refund_amount", WalletServiceConstants.amount);
    	request.getDynamicPayload().setProperty("currency", WalletServiceConstants.uaeCurrency);
    	request.getDynamicPayload().setProperty("txn_id", "AAAAAAAAAAAAAAAA");
    	BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                request.getHeaders(), reqBody, request.getDynamicPayload());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_RefundWithInvalidId", apiResponse);
		return apiResponse;
    }
    
    @Test(groups="actualCall", dataProvider = "dataProvider")
    @ApiTest(api = "refundWithWrongTxnId")
    public void verifyApiCodeForRefund(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }
    
    @Test(groups="actualCall", dataProvider = "dataProvider")
	@ApiTest(api = "refundWithWrongTxnId")
	public void verifyApiStatusKeyForRefund(Response response) {
		response.then().assertThat().body("status", equalTo("BAD_REQUEST"));
	}
    
    @SuppressWarnings("unchecked")
	@Test(dependsOnGroups= {"afterCall"})
    public void validateNoAmountRefunded() {
    	String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	double totalBalanceBefore = Utility.convertStringIntoDouble(data.get("total_balance").toString());
    	logger.info("totalBalanceBefore=>"+totalBalanceBefore);
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double totalBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("total_balance").toString());
    	logger.info("totalBalanceAfter=>"+totalBalanceAfter);
    	
    	assertEquals(totalBalanceAfter, totalBalanceBefore);
    	
    }
}
