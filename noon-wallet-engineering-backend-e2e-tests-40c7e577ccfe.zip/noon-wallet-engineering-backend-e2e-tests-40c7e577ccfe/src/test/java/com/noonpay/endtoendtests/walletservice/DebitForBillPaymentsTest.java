package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Constants;
import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/wallet/customer/v1/debit?f=9")
public class DebitForBillPaymentsTest extends BaseTest{
	
	static Logger logger = Logger.getLogger(DebitForBillPaymentsTest.class);

	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "walletDebitForMobile")
    private Response apiCall(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	request.getDynamicPayload().setProperty("amount", WalletServiceConstants.amount);
    	request.getDynamicPayload().setProperty("currency", Constants.uaeCurrency);
    	request.getDynamicPayload().setProperty("txn_ref_id", Utility.generate16CharRndStr());
    	BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                request.getHeaders(), reqBody, request.getDynamicPayload());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_DebitForBillPayments", apiResponse);
    	getDebitTxnId();
		return apiResponse;
    }
    
    @SuppressWarnings("unchecked")
	public static String getDebitTxnId() {
    	String debitResponse=WalletResponse.getWalletData("Response_DebitForBillPayments");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(debitResponse).get("data");
		String debitTxnId = data.get("debit_txn_id").toString();
		return debitTxnId;
    }
    
    @Test(groups = {"actualCall"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall"})
    @ApiTest(api = "walletDebitForMobile")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(groups = {"actualCall"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall"})
    @ApiTest(api = "walletDebitForMobile")
    public void verifyResponseStatus(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }
   
    @SuppressWarnings("unchecked")
	@Test(dependsOnGroups= {"afterCall"})
    public void verifyWalletMoneyDeducted() {
    	String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	double totalBalanceBefore = Utility.convertStringIntoDouble(data.get("total_balance").toString());
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double totalBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("total_balance").toString());
    	
    	String amountUsed=WalletServiceConstants.amount;
    	double amountDebited=Utility.convertStringIntoDouble(amountUsed);
    	BigDecimal expAmountAfterAddition = BigDecimal.valueOf(totalBalanceBefore)
				.subtract(BigDecimal.valueOf(amountDebited));
		double expAmount = expAmountAfterAddition.doubleValue();
		logger.info("expAmount=>"+expAmount);
    	assertEquals(totalBalanceAfter, expAmount);
    }
    
}
