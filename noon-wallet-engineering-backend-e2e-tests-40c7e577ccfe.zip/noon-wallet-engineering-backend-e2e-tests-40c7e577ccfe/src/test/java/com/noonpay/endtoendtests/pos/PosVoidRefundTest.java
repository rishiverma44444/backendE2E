package com.noonpay.endtoendtests.pos;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Constants;
import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.endtoendtests.walletservice.WalletResponse;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/pos/customer/v1/refund")
public class PosVoidRefundTest extends BaseTest{

static Logger logger = Logger.getLogger(PosVoidRefundTest.class);
	
	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;
    
    @Api(name = "posVoidRefund")
    private Response apiCallVoidRefund(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	logger.info("DEBIT PAYMENT ID=>"+getDebitPaymentId());
    	request.getDynamicPayload().setProperty("payment_id", getDebitPaymentId());
    	request.getDynamicPayload().setProperty("currency", Constants.uaeCurrency);
    	request.getDynamicPayload().setProperty("refund_amount", getTotalDebitAmount());
    	request.getDynamicPayload().setProperty("refund_type", "VOID");
    	request.getDynamicPayload().setProperty("txn_channel", "BILL_PAYMENTS");
    	BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                request.getHeaders(), reqBody, request.getDynamicPayload());
    	Response apiResponse =response.getResponse();
    	PosResponse.setPosData("Response_PosVoidRefund", apiResponse);
		return apiResponse;
    }
    
    @Test(groups= {"actualCall"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall","actualCall1"})
    @ApiTest(api = "posVoidRefund")
    public void verifyApiCodeVoidRefund(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(groups= {"actualCall"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall","actualCall1"})
    @ApiTest(api = "posVoidRefund")
    public void verifyApiStatusVoidRefund(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }
    
    @SuppressWarnings("unchecked")
	@Test(groups= {"actualCall"}, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall","actualCall1"})
    @ApiTest(api = "posVoidRefund")
    public void verifyRefundSuccessResponse(Response response) {
    	String posResponse=PosResponse.getPosData("Response_PosVoidRefund");
    	Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(posResponse).get("data");
    	String isRefundSuccess=data.get("refund_success").toString();
    	assertEquals(isRefundSuccess, "true");
    }
    
    @SuppressWarnings("unchecked")
	@Test(dependsOnGroups= {"afterCall"})
    public void validateVoidRefundSuccess() {
    	String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	double totalBalanceBefore = Utility.convertStringIntoDouble(data.get("total_balance").toString());
    	logger.info("totalBalanceBefore=>"+totalBalanceBefore);
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double totalBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("total_balance").toString());
    	logger.info("totalBalanceAfter=>"+totalBalanceAfter);
    	
    	assertEquals(totalBalanceBefore, totalBalanceAfter);
    }
    
    @SuppressWarnings("unchecked")
	public static String getDebitPaymentId() {
    	String responseData=PosResponse.getPosData("Response_PosDebitWalletBalance");
    	Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(responseData).get("data");
    	String debitSuccessResponse=data.get("debit_pay_success_response").toString();
    	String paymentId= Utility.converStringResponseIntoJsonObject(debitSuccessResponse).get("payment_id").toString();
    	return paymentId;
    }
    
    @SuppressWarnings("unchecked")
	public static String getTotalDebitAmount() {
    	String responseData=PosResponse.getPosData("Response_PosDebitWalletBalance");
    	Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(responseData).get("data");
    	String debitSuccessResponse=data.get("debit_pay_success_response").toString();
    	String totalAmount= Utility.converStringResponseIntoJsonObject(debitSuccessResponse).get("total_amount").toString();
    	return totalAmount;
    }
}
