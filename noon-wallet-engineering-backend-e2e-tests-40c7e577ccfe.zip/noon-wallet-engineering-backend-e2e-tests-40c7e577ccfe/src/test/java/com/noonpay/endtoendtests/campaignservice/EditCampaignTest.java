package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;


@TestDataSetup(endpoint = "/campaign/v1/edit")
public class EditCampaignTest extends BaseTest {

    static Logger logger = Logger.getLogger(EditCampaignTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "editCampaignPositive")
    private Response apiCall_editCampaignPositive(TestData data) {
        data = EditCampaign.populateDataForPositiveFlow(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.putObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_editCampaignPositive", apiResponse.asString());
        logger.info("Edit campaign positive api response =>" +CampaignResponse.campaignData.get("Response_editCampaignPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignPositive")
    public void verifyValueOfStatusKey(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignPositive")
    public void verifyValueOfDataKey(Response response) {
        response.then().assertThat().body("data", equalTo(true));
    }


    @Api(name = "editCampaignNegative_StartTime")
    private Response apiCall_editCampaignNegativeStartTime(TestData data) {
        data = EditCampaign.populateDataForPastStartTime(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.putObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_editCampaignNegative_StartTime", apiResponse.asString());
        logger.info("Edit campaign negative start time api response =>" +CampaignResponse.campaignData.get("Response_editCampaignNegative_StartTime"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_StartTime")
    public void verifyStatusCode_NegativeStartTime(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_StartTime")
    public void verifyValueOfStatusKey_NegativeStartTime(Response response) {
        Utility.checkValueFromResponse(response, "status", "BAD_REQUEST");
    }


    @Api(name = "editCampaignNegative_EndTime")
    private Response apiCall_editCampaignNegativeEndTime(TestData data) {
        data = EditCampaign.populateDataForPastEndTime(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.putObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_editCampaignNegative_EndTime", apiResponse.asString());
        logger.info("Edit campaign negative end time api response =>" +CampaignResponse.campaignData.get("Response_editCampaignNegative_EndTime"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_EndTime")
    public void verifyStatusCode_NegativeEndTime(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_EndTime")
    public void verifyValueOfStatusKey_NegativeEndTime(Response response) {
        Utility.checkValueFromResponse(response, "status", "BAD_REQUEST");
    }


    @Api(name = "editCampaignNegative_OfferId")
    private Response apiCall_editCampaignNegativeOfferId(TestData data) {
        data = EditCampaign.populateDataForInvalidOffer(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.putObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_editCampaignNegative_OfferId", apiResponse.asString());
        logger.info("Edit campaign invalid offerId api response =>" +CampaignResponse.campaignData.get("Response_editCampaignNegative_OfferId"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_OfferId")
    public void verifyStatusCode_NegativeOfferId(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_INTERNAL_SERVER_ERROR);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_OfferId")
    public void verifyValueOfMessageKey_NegativeOfferId(Response response) {
        Utility.checkValueFromResponse(response, "message", "No Offers Details Available");
    }


    @Api(name = "editCampaignNegative_CampaignId")
    private Response apiCall_editCampaignNegativeCampaignId(TestData data) {
        data = EditCampaign.populateDataForInvalidCampaignId(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.putObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_editCampaignNegative_CampaignId", apiResponse.asString());
        logger.info("Edit campaign invalid campaignId api response =>" +CampaignResponse.campaignData.get("Response_editCampaignNegative_CampaignId"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_CampaignId")
    public void verifyStatusCode_NegativeCampaignId(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "editCampaignNegative_CampaignId")
    public void verifyValueOfMessageKey_NegativeCampaignId(Response response) {
        Utility.checkValueFromResponse(response, "message", "campaign not found");
    }


}
