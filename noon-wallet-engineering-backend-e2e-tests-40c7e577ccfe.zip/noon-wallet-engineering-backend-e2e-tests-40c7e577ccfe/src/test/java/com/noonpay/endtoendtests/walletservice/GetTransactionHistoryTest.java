package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/wallet/customer/v1/history")
public class GetTransactionHistoryTest extends BaseTest{

	@Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "getTransactionHistory")
    private Response apiCall(TestData data) {
    	ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	BaseResponse response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), request.getHeaders(), request.getQueryParams());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_GetTransactionHistory", apiResponse);
		return apiResponse;
    }
    
    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "getTransactionHistory")
    public void verifyApiCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }
    
    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "getTransactionHistory")
    public void verifyApiStatus(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }
    
    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "getTransactionHistory")
    private void verifyTransactionsAreReturned(Response response) {
    	System.out.println("SIZE IS: "+response.jsonPath().get("$.data.transaction_history.length"));
    	
    	
    }
}
