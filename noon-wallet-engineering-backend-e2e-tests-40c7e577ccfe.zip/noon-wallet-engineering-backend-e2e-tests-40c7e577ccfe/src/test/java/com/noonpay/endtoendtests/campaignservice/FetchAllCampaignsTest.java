package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.custom.report.CustomLogger;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

@TestDataSetup(endpoint = "/campaign/v1/campaigns?f=1")
public class FetchAllCampaignsTest extends BaseTest {

    static Logger logger = Logger.getLogger(FetchAllCampaignsTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchAllCampaignsPositive")
    private Response apiCall_fetchAllCampaignsPositive(TestData data) throws InterruptedException {
        Thread.sleep(5000);
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_fetchAllCampaignsPositive", apiResponse.asString());
        logger.info("Fetch campaign positive api response =>" +CampaignResponse.campaignData.get("Response_fetchAllCampaignsPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllCampaignsPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllCampaignsPositive")
    public void verifyValueOfStatusKey(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }

    @Test()
    @ApiTest(api = "fetchAllCampaignsPositive")
    public void verifyAddedCampaignPresentInResponse() {
        String campaignTitle = CampaignResponse.campaignData.get("Payload_campaignTitle");
        String apiResponse = CampaignResponse.campaignData.get("Response_fetchAllCampaignsPositive");
        String campaignId = Utility.getCampaignIdBySearchingTitle(apiResponse, campaignTitle);
        CampaignResponse.campaignData.put("addCampaign_campaignId", campaignId);
        logger.info("CampaignId from map for add campaign =>" +campaignId);
        assertNotEquals(campaignId, "");
    }

    @Api(name = "fetchAllCampaignsAfterCampaignEdit")
    private Response apiCall_fetchAllCampaignsAfterCampaignEdit(TestData data) throws InterruptedException {
        Thread.sleep(5000);
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_fetchAllCampaignsAfterCampaignEdit", apiResponse.asString());
        logger.info("Fetch campaign positive after edit campaign api response =>" +CampaignResponse.campaignData.get("Response_fetchAllCampaignsAfterCampaignEdit"));
        return apiResponse;
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchAllCampaignsAfterCampaignEdit")
    public void verifyStatusCode_EditCampaign(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }

    @Test()
    @ApiTest(api = "fetchAllCampaignsAfterCampaignEdit")
    public void verifyEditedCampaignPresentInResponse() {
        String campaignTitle = CampaignResponse.campaignData.get("Payload_campaignTitleUpdated");
        String apiResponse = CampaignResponse.campaignData.get("Response_fetchAllCampaignsAfterCampaignEdit");
        String campaignId = Utility.getCampaignIdBySearchingTitle(apiResponse, campaignTitle);
        CampaignResponse.campaignData.put("editCampaign_campaignId", campaignId);
        logger.info("CampaignId from map for edit campaign=>" + campaignId);
        assertEquals(CampaignResponse.campaignData.get("editCampaign_campaignId"), CampaignResponse.campaignData.get("addCampaign_campaignId"));
    }

}
