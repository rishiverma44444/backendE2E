package com.noonpay.endtoendtests.walletservice;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.ApiRequest;
import com.noonpay.qa.common.model.BaseResponse;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;

import io.restassured.response.Response;

@TestDataSetup(endpoint = "/wallet/customer/v1/debit?f=RECHARGE")
public class WalletDebitTest extends BaseTest {
	
	static Logger logger = Logger.getLogger(WalletDebitTest.class);
	
	static double differenceInMainBlnc;
	static double differenceInCBBlnc;

	@Autowired
	private APIUrlProvider apiUrlProvider;

	@Autowired
	private RestAssuredClient restAssuredClient;

	@Api(name = "debitCall")
	private Response debitBalance(TestData data) {
		ApiRequest request=getRequestId(data);
    	String reqBody= getRequestBody(data.getService());
    	request.getDynamicPayload().setProperty("amount", WalletServiceConstants.amount);
    	request.getDynamicPayload().setProperty("currency", WalletServiceConstants.uaeCurrency);
    	request.getDynamicPayload().setProperty("txn_ref_id", Utility.generate16CharRndStr());
    	BaseResponse response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                request.getHeaders(), reqBody, request.getDynamicPayload());
    	Response apiResponse =response.getResponse();
    	WalletResponse.setWalletData("Response_WalletDebitTest", apiResponse);
    	getDebitTxnId();
		return apiResponse;
	}
	
	@SuppressWarnings("unchecked")
	public static String getDebitTxnId() {
		String debitResponse=WalletResponse.getWalletData("Response_WalletDebitTest");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(debitResponse).get("data");
		String debitTxnId = data.get("debit_txn_id").toString();
		return debitTxnId;
		
    }

	@Test(groups = { "actualCall" }, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall"})
	@ApiTest(api = "debitCall")
	public void verifyStatusCode(Response response) {
		assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
	}

	@Test(groups = { "actualCall" }, dataProvider = "dataProvider", dependsOnGroups= {"preBalanceCall"})
	@ApiTest(api = "debitCall")
	public void verifyValueOfStatusKey(Response response) {
		response.then().assertThat().body("status", equalTo("OK"));
	}

	@SuppressWarnings("unchecked")
	@Test(dependsOnGroups = { "afterCall" })
	public void verifyBalanceDeductedFromWallet() {
		String balanceResponseBefore=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore).get("data");
    	double mainBalanceBefore = Utility.convertStringIntoDouble(data.get("main_balance").toString());
    	logger.info("mainBalanceBefore=>"+mainBalanceBefore);
    	
    	String balanceResponseAfter=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter).get("data");
    	double mainBalanceAfter = Utility.convertStringIntoDouble(dataAfter.get("main_balance").toString());
    	logger.info("mainBalanceAfter=>"+mainBalanceAfter);
    	
    	BigDecimal differenceAmnt=BigDecimal.valueOf(mainBalanceBefore).subtract(BigDecimal.valueOf(mainBalanceAfter));
    	differenceInMainBlnc=differenceAmnt.doubleValue();
    	
    	String balanceResponseBefore1=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data1 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore1).get("data");
    	double cashbackBalanceBefore = Utility.convertStringIntoDouble(data1.get("cashback_balance").toString());
    	logger.info("cashbackBalanceBefore=>"+cashbackBalanceBefore);
    	
    	String balanceResponseAfter1=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter1 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter1).get("data");
    	double cashbackBalanceAfter = Utility.convertStringIntoDouble(dataAfter1.get("cashback_balance").toString());
    	logger.info("cashbackBalanceAfter=>"+cashbackBalanceAfter);
    	
    	BigDecimal differenceAmnt1=BigDecimal.valueOf(cashbackBalanceBefore).subtract(BigDecimal.valueOf(cashbackBalanceAfter));
    	differenceInCBBlnc=differenceAmnt1.doubleValue();
		
		
		String balanceResponseBefore2=WalletResponse.getWalletData("Response_CheckCustomerBalanceBefore");
		Map<String, Object> data2 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseBefore2).get("data");
    	double totalBalanceBefore = Utility.convertStringIntoDouble(data2.get("total_balance").toString());
    	logger.info("totalBalanceBefore=>"+totalBalanceBefore);
    	
    	String balanceResponseAfter2=WalletResponse.getWalletData("Response_CheckCustomerBalanceAfter");
    	Map<String, Object> dataAfter2 = (Map) Utility.converStringResponseIntoJsonObject(balanceResponseAfter2).get("data");
    	double totalBalanceAfter = Utility.convertStringIntoDouble(dataAfter2.get("total_balance").toString());
    	logger.info("totalBalanceAfter=>"+totalBalanceAfter);
    	
    	double amountUsed=Utility.convertStringIntoDouble(WalletServiceConstants.amount);
    	BigDecimal expAmount=BigDecimal.valueOf(totalBalanceBefore).subtract(BigDecimal.valueOf(amountUsed));
    	double expFinalAmount=expAmount.doubleValue();
    	logger.info("expFinalAmount=>"+expFinalAmount);
    	
    	assertEquals(totalBalanceAfter, expFinalAmount);
		

	}
	
}
