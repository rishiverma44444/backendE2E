package com.noonpay.endtoendtests.rechargeservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.testng.Assert.assertEquals;

@TestDataSetup(endpoint = "/recharge/v1/fetch/intl/countries")
public class FetchIntlCountriesTest extends BaseTest {

    static Logger logger = Logger.getLogger(FetchIntlCountriesTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "fetchIntlCountriesPositive")
    private Response apiCall(TestData data) {
        Map<String, Object> response = restAssuredClient.getObject(apiUrlProvider.getUrl(data.getEndpoint()), data.getHeaders());
        Response apiResponse = (Response) response.get("response");
        RechargeResponse.rechargeData.put("Response_fetchIntlCountriesPositive", apiResponse.asString());
        logger.info("Api response =>" + RechargeResponse.rechargeData.get("Response_fetchIntlCountriesPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchIntlCountriesPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchIntlCountriesPositive")
    public void verifyValueOfStatusKey(Response response) {
        Utility.checkValueFromResponse(response, "status", "OK");
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "fetchIntlCountriesPositive")
    public void verifyIntlCountriesPlansNotNull(Response response) {
        String apiResponse = RechargeResponse.rechargeData.get("Response_fetchIntlCountriesPositive");
        Utility.checkSizeOfArrayNotNull(apiResponse, "$..countries[0:]");
    }

}

