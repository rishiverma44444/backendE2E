package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.connector.RestAssuredClient;
import com.noonpay.qa.common.constants.TestingType;
import com.noonpay.qa.common.custom.annotations.Api;
import com.noonpay.qa.common.custom.annotations.ApiTest;
import com.noonpay.qa.common.custom.annotations.TestDataSetup;
import com.noonpay.qa.common.custom.report.CustomLogger;
import com.noonpay.qa.common.model.TestData;
import com.noonpay.qa.common.test.BaseTest;
import com.noonpay.qa.common.util.APIUrlProvider;
import io.restassured.response.Response;
import org.apache.http.HttpStatus;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.*;

@TestDataSetup(endpoint = "/campaign/v1/validate")
public class PreValidateCampaignTest extends BaseTest {
    static Logger logger = Logger.getLogger(PreValidateCampaignTest.class);

    @Autowired
    private APIUrlProvider apiUrlProvider;

    @Autowired
    private RestAssuredClient restAssuredClient;

    @Api(name = "preValidateCampaignPositive")
    private Response apiCall_preValidateCampaignPositive(TestData data) {
        data = PreValidateCampaign.populateDataForPositiveFlow(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_preValidateCampaignPositive", apiResponse.asString());
        logger.info("Api response =>" + CampaignResponse.campaignData.get("Response_preValidateCampaignPositive"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignPositive")
    public void verifyStatusCode(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignPositive")
    public void verifyValueOfStatusKey(Response response) {
        response.then().assertThat().body("status", equalTo("OK"));
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignPositive")
    public void verifyValueOfApplicableKey(Response response) {
        response.then().assertThat().body("data.applicable", equalTo(true));
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignPositive")
    public void verifyTxnIdNotNull(Response response) {
        String apiResponse = CampaignResponse.campaignData.get("Response_preValidateCampaignPositive");
        String campaignTxnId = Utility.getValueFromJsonPath(apiResponse, "$.data.campaignTxnId");
        CampaignResponse.campaignData.put("preValidateCampaign_campaignTxnId", campaignTxnId);
        assertNotEquals(campaignTxnId, "");
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignPositive")
    public void verifyValueOfCampaignIdKey(Response response) {
        String apiResponse = CampaignResponse.campaignData.get("Response_preValidateCampaignPositive");
        String campaignTxnId = Utility.getValueFromJsonPath(apiResponse, "$.data.campaignId");
        CampaignResponse.campaignData.put("preValidateCampaign_campaignId", campaignTxnId);
        assertNotEquals(campaignTxnId, "");
    }


    @Api(name = "preValidateCampaignNegative_DifferentCurrency")
    private Response apiCall_preValidateCampaignNegativeDifferentCurrency(TestData data) {
        data = PreValidateCampaign.populateDataForDifferentCurrency(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_preValidateCampaignNegative_DifferentCurrency", apiResponse.asString());
        logger.info("Api response =>" + CampaignResponse.campaignData.get("Response_preValidateCampaignNegative_DifferentCurrency"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignNegative_DifferentCurrency")
    public void verifyStatusCode_NegativeDifferentCurrency(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignNegative_DifferentCurrency")
    public void verifyValueOfDescriptionKey_NegativeDifferentCurrency(Response response) {
        response.then().assertThat().body("data.description", equalTo("Campaign Currency is different than Transaction Currency"));
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignNegative_DifferentCurrency")
    public void verifyTxnIdIsNull_NegativeDifferentCurrency(Response response) {
        String apiResponse = CampaignResponse.campaignData.get("Response_preValidateCampaignNegative_DifferentCurrency");
        String campaignTxnId = Utility.getValueFromJsonPath(apiResponse, "$.data.campaignTxnId");
        assertNull(campaignTxnId);
    }


    @Api(name = "preValidateCampaignNegative_LessThanMinAmount")
    private Response apiCall_preValidateCampaignNegativeLessThanMinAmount(TestData data) {
        data = PreValidateCampaign.populateDataForLessThanMinAmount(data);
        String formattedString = data.getSampleRequest().replace("\\", "");
        Map<String, Object> response = restAssuredClient.postObject(apiUrlProvider.getUrl(data.getEndpoint()),
                data.getHeaders(), formattedString, data.getProperties());
        Response apiResponse = (Response) response.get("response");
        CampaignResponse.campaignData.put("Response_preValidateCampaignNegative_LessThanMinAmount", apiResponse.asString());
        logger.info("Api response =>" + CampaignResponse.campaignData.get("Response_preValidateCampaignNegative_LessThanMinAmount"));
        return apiResponse;
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignNegative_LessThanMinAmount")
    public void verifyStatusCode_NegativeMinAmount(Response response) {
        assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
    }


    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignNegative_LessThanMinAmount")
    public void verifyValueOfDescriptionKey_NegativeMinAmount(Response response) {
        response.then().assertThat().body("data.description", equalTo("Min Amount to avail this offer is AED 10.00"));
    }

    @Test(dataProvider = "dataProvider")
    @ApiTest(api = "preValidateCampaignNegative_LessThanMinAmount")
    public void verifyTxnIdIsNull_NegativeMinAmount(Response response) {
        String apiResponse = CampaignResponse.campaignData.get("Response_preValidateCampaignNegative_LessThanMinAmount");
        String campaignTxnId = Utility.getValueFromJsonPath(apiResponse, "$.data.campaignTxnId");
        assertNull(campaignTxnId);
    }


}
