package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.qa.common.model.TestData;
import com.noonpay.endtoendtests.utilities.Utility;

import java.util.Map;
import java.util.Properties;

public class AddCampaign {

    public static TestData populateDataForPositiveFlow(TestData data) {
        Properties prop = data.getProperties();
        String title_en = "title_en" + System.currentTimeMillis();
        String title_er = "title_er" + System.currentTimeMillis();
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "SECONDS", 5));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 5));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", title_en);
        prop.setProperty("title_er", title_er);
        CampaignResponse.campaignData.put("Payload_campaignTitle", title_en);
        return data;
    }

    public static TestData populateDataForPastStartTime(TestData data) {
        Properties prop = data.getProperties();
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "YEARS", -1));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 5));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }


    public static TestData populateDataForPastEndTime(TestData data) {
        Properties prop = data.getProperties();
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", -1));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }

    public static TestData populateDataForInvalidOffer(TestData data) {
        Properties prop = data.getProperties();
        String offerId = "Offer" + System.currentTimeMillis();
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("offer_id", offerId);
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }
}
