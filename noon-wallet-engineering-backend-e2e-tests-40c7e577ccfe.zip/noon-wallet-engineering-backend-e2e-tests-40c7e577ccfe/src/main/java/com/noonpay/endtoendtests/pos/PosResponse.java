package com.noonpay.endtoendtests.pos;

import java.util.HashMap;
import java.util.Map;

import io.restassured.response.Response;

public class PosResponse {

	public static Map<String, Object> posData = new HashMap<>();
	
	public static void setPosData(String key, Response response) {
		posData.put(key, response.getBody().asString());
	}
	
	public static String getPosData(String key) {
		return posData.get(key).toString();
	}
}
