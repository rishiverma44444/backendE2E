package com.noonpay.endtoendtests.walletservice;


import com.noonpay.endtoendtests.utilities.Constants;
import com.noonpay.qa.common.model.TestData;

public class WalletRefund {

	public static TestData populateData(TestData data) {
		String debitTxnId=WalletResponse.walletData.get("WalletDebitTxnId").toString();
		
		data.getProperties().setProperty("refund_amount", "10.00");
		data.getProperties().setProperty("currency", "AED");
		data.getProperties().setProperty("txn_id",debitTxnId);
		
		data.getHeaders().put(Constants.authorization,"cge-070a23c3-075e-4b07-8027-5a3c0fad8e9f");
        data.getHeaders().put(Constants.version,"000");
        data.getHeaders().put(Constants.deviceId,"0");
        data.getHeaders().put(Constants.device,"00");
        data.getHeaders().put(Constants.platformId,"ANDROID");
        data.getHeaders().put(Constants.locale,"EN");
        
        return data;
    }
}
