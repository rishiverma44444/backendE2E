package com.noonpay.endtoendtests.utilities;

public class Constants {
	
	public static double balanceToLoadInWallet=10.00;
	
    public static final String version="X-NVersion";
    public static final String device="X-NDevice";
    public static final String deviceId="X-NDeviceId";
    public static final String platformId="X-NPlatformId";
    public static final String locale="X-NLocale";
    public static final String authorization="Authorization";
    
    public static final String amount="10.00";
    public static final String p2pTxnAmnt="10.00";
    public static final String p2pLoadAmnt="5.00";
	public static final String uaeCurrency="AED";
	public static final String ksaCurrency="SAR";
	public static final String country_uae="UAE";
	public static final String country_ksa="KSA";
	public static final String uae_receiver_with_kyc2_mobile="971569355887";
	public static final String uae_uat_receiver_with_kyc2_mobile="971569705887";
	public static final String uae_receiver_with_kyc1_mobile="971511351010";
	public static final String uae_uat_receiver_with_kyc1_mobile="971511394010";
	public static final String ksa_receiver_with_kyc2_mobile="966513450098";
	

}
