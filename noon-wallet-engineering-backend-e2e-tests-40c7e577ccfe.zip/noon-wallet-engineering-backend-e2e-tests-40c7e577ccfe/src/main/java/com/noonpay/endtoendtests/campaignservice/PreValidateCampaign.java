package com.noonpay.endtoendtests.campaignservice;

import com.noonpay.qa.common.model.TestData;

import java.util.Properties;

public class PreValidateCampaign {

    public static TestData populateDataForPositiveFlow(TestData data) {
        Properties prop = data.getProperties();
        prop.setProperty("amount", "10");
        prop.setProperty("currency", "AED");
        prop.setProperty("feature_id", "1");
        return data;
    }

    public static TestData populateDataForDifferentCurrency(TestData data) {
        Properties prop = data.getProperties();
        prop.setProperty("amount", "10");
        prop.setProperty("currency", "SAR");
        prop.setProperty("feature_id", "1");
        return data;
    }

    public static TestData populateDataForLessThanMinAmount(TestData data) {
        Properties prop = data.getProperties();
        prop.setProperty("amount", "1");
        prop.setProperty("currency", "AED");
        prop.setProperty("feature_id", "1");
        return data;
    }
}
