package com.noonpay.endtoendtests.rechargeservice;

import java.util.HashMap;
import java.util.Map;

public class RechargeResponse {

    public static Map<String, String> rechargeData = new HashMap<>();
}

