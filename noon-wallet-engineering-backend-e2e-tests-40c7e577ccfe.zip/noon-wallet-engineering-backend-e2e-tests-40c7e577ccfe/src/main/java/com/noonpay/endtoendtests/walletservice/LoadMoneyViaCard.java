package com.noonpay.endtoendtests.walletservice;

import com.noonpay.endtoendtests.utilities.Constants;
import com.noonpay.qa.common.model.TestData;

public class LoadMoneyViaCard {
	
	public static TestData populateData(TestData data) {
		data.getProperties().setProperty("amount", Constants.balanceToLoadInWallet+"");
		data.getProperties().setProperty("currency", "AED");
		data.getProperties().setProperty("number",
				"V/WuvXcGP/J0ZpDJMM1XDEbmqUyGPLDrEjb0jHW1XZpWfbeIsr//drekJevAdXQ0EcEcGkXmORDRhPWBeZKKecwMXbnpYfCR1SJ2xNX5bUEK/l5VNUWYSRW2KulJUgnIDMsSXWKzefpiCvF7v6lsi5F3uSXxJO7CVdTUTt654LLnzYzwe7mz1iWCJnpH+mBzmE9pgEQNbCDt+vQyd2Dv4jR7XXZQE5CbDy9j+u3XptB7ueVDp8v3EdaZJz6bT4O2rl5FeeDg0psHszOHz0qzVsOtYfAtLgpMUdxPXndRThgGKQYrcii43IQQ3rQf6AB2wDN/NxCQvHoJZeWQcD1KuQ==");
		data.getProperties().setProperty("txn_ref_id", "3ZCM40Y5HP2LXFYB");
		
        data.getHeaders().put(Constants.authorization,"cge-070a23c3-075e-4b07-8027-5a3c0fad8e9f");
        data.getHeaders().put(Constants.version,"000");
        data.getHeaders().put(Constants.deviceId,"0");
        data.getHeaders().put(Constants.device,"00");
        data.getHeaders().put(Constants.platformId,"ANDROID");
        data.getHeaders().put(Constants.locale,"EN");
        return data;
    }
}
