package com.noonpay.endtoendtests.walletservice;

public class WalletServiceConstants {
	
	public static final String amount="10.00";
	public static final String amountToAdd="100.00";

	public static final String uaeCurrency="AED";
	public static final String ksaCurrency="SAR";
	
	public static final String cashbackExpiryTime="2022-08-08";
}
