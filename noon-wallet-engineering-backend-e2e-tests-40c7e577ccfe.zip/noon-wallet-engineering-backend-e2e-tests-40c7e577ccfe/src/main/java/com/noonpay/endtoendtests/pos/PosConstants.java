package com.noonpay.endtoendtests.pos;

public class PosConstants {

	public static final String amount="10.00";
	public static final String merchantId="REC_GULFBOX_ID";
	public static final double merchantTxnFee=0.20;
}
