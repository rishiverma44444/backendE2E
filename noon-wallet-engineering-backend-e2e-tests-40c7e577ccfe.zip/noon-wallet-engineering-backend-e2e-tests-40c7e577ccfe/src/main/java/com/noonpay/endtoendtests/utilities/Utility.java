package com.noonpay.endtoendtests.utilities;

import com.jayway.jsonpath.JsonPath;
import io.restassured.response.Response;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasKey;
import static org.testng.Assert.assertNotNull;

public class Utility {

    public static String getCurrentDateTime(String zone) {
        LocalDateTime date = LocalDateTime.now(ZoneId.of(zone));
        DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return date.format(format1);
    }

    public static String getDateTimeAfterModification(String zone, String variable, int value) {
        LocalDateTime date = LocalDateTime.now(ZoneId.of(zone));
        DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        switch (variable) {
            case "SECONDS":
                date = date.plus(value, ChronoUnit.SECONDS);
                break;
            case "DAYS":
                date = date.plus(value, ChronoUnit.DAYS);
                break;
            case "YEARS":
                date = date.plus(value, ChronoUnit.YEARS);
                break;
            default:
                System.out.println("Please enter valid variable for modifying value");
        }

        return date.format(format1);
    }

    public static void checkValueFromResponse(Response response, String key, Object expectedValue) {
        response.then().assertThat().body(key, equalTo(expectedValue));
    }

    public static String getCampaignIdBySearchingTitle(String apiResponse, String campaignTitle) {
        String campaignId = "";
        List<String> title = JsonPath.read(apiResponse, "$.data.campaign[*].title");
        for (int i = 0; i < title.size(); i++) {
            if (title.get(i).equals(campaignTitle)) {
                campaignId = JsonPath.read(apiResponse, "$.data.campaign[" + i + "].campaign_id");
                break;
            }
        }
        return campaignId;
    }

    
    public static JSONObject converStringResponseIntoJsonObject(String response) {
    	JSONObject json=null;
    	JSONParser parser = new JSONParser(); 
    	try {
			json = (JSONObject) parser.parse(response);
		} catch (ParseException e) {
			e.printStackTrace();
		}
    	return json;
    }
    
    public static double convertStringIntoDouble(String str) {
    	double d = Double.parseDouble(str);
    	return d;
    }


    public static String getValueFromJsonPath(String apiResponse, String jsonPath) {
        return JsonPath.read(apiResponse, jsonPath);
    }

    public static void isKeyPresentInResponse(Response response, String key) {
        response.then().assertThat().body("$", hasKey(key));
    }

    public static void checkSizeOfArrayNotNull(String apiResponse, String jsonPath) {
        List<String> countries = JsonPath.read(apiResponse, jsonPath);
        assertNotNull(countries);
    }
    
    public static String generate16CharRndStr() {
    	String result = new SecureRandom().ints(0,36)
	            .mapToObj(i -> Integer.toString(i, 36))
	            .map(String::toUpperCase).distinct().limit(16).collect(Collectors.joining())
	            .replaceAll("([A-Z0-9]{4})", "$1-").substring(0,19);

	        return result.replace("-", "");
    }


}
