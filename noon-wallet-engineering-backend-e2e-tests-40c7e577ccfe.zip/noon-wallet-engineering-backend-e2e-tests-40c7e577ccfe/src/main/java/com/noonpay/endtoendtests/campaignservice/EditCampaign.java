package com.noonpay.endtoendtests.campaignservice;


import com.noonpay.endtoendtests.utilities.Utility;
import com.noonpay.qa.common.model.TestData;

import java.util.Properties;

public class EditCampaign {

    public static TestData populateDataForPositiveFlow(TestData data) {
        Properties prop = data.getProperties();
        String title_en = "title_en" + System.currentTimeMillis();
        String campaignId = CampaignResponse.campaignData.get("addCampaign_campaignId");
        prop.setProperty("campaign_id", campaignId);
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "SECONDS", 5));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 5));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", title_en);
        prop.setProperty("title_ar", "title_ar");

        CampaignResponse.campaignData.put("Payload_campaignTitleUpdated", title_en);
        return data;
    }

    public static TestData populateDataForPastStartTime(TestData data) {
        Properties prop = data.getProperties();
        String campaignId = CampaignResponse.campaignData.get("addCampaign_campaignId");
        prop.setProperty("campaign_id", campaignId);
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "DAYS", -10));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 5));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }

    public static TestData populateDataForPastEndTime(TestData data) {
        Properties prop = data.getProperties();
        String campaignId = CampaignResponse.campaignData.get("addCampaign_campaignId");
        prop.setProperty("campaign_id", campaignId);
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", -3));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }

    public static TestData populateDataForInvalidOffer(TestData data) {
        Properties prop = data.getProperties();
        String campaignId = CampaignResponse.campaignData.get("addCampaign_campaignId");
        prop.setProperty("campaign_id", campaignId);
        String offerId = "Offer" + System.currentTimeMillis();
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("offer_id", offerId);
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }

    public static TestData populateDataForInvalidCampaignId(TestData data) {
        Properties prop = data.getProperties();
        String campaignId = "CampaignId" + System.currentTimeMillis();
        prop.setProperty("campaign_id", campaignId);
        prop.setProperty("start_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("end_at", Utility.getDateTimeAfterModification("GMT", "YEARS", 1));
        prop.setProperty("offer_id", "e2e_Offer_1");
        prop.setProperty("coupon_code", "e2e_coupon_code");
        prop.setProperty("title_en", "title_en");
        prop.setProperty("title_er", "title_er");
        return data;
    }

}

