package com.noonpay.endtoendtests.campaignservice;

import java.util.HashMap;
import java.util.Map;

public class CampaignResponse {

    public static Map<String, String> campaignData = new HashMap<>();
}
