package com.noonpay.endtoendtests.walletservice;

import java.util.HashMap;
import java.util.Map;

import io.restassured.response.Response;

public class WalletResponse {

	private static Map<String, Object> walletData = new HashMap<>();
	
	
	
	public static String getWalletData(String key) {
		return walletData.get(key).toString();
	}

	public static void setWalletData(String key, Response response) {
		walletData.put(key, response.getBody().asString());
	}
}
