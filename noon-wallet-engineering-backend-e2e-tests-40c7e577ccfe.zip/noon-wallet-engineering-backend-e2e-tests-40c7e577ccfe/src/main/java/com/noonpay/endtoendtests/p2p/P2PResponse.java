package com.noonpay.endtoendtests.p2p;

import java.util.HashMap;
import java.util.Map;

import io.restassured.response.Response;

public class P2PResponse {

    private static Map<String, Object> p2pData = new HashMap<>();
	
	public static String getP2PData(String key) {
		return p2pData.get(key).toString();
	}

	public static void setP2PData(String key, Response response) {
		p2pData.put(key, response.getBody().asString());
	}
}
